import time
from math import log, pow
import numpy as np
import matplotlib.pyplot as plt


def in_one_octave(pitch_ref, pitch_est):
    diff = abs(pitch_ref - pitch_est)
  
    while(diff > 6):
        if pitch_ref >= pitch_est:
            pitch_est += 12
        else:
            pitch_est -= 12
        
        
        diff = abs(pitch_ref - pitch_est)
        

    return pitch_est

def norm(x, x_min, x_max):
    y_min = 0
    y_max = np.pi
    y = y_min + ((y_max - y_min) / (x_max - x_min)) * (x- x_min)
    return y

def scoring(pitch_ref, pitch_est_new):
    pitch_ref_left = pitch_ref - 1
    pitch_ref_right = pitch_ref + 1
    if pitch_est_new <= pitch_ref_left or pitch_est_new >= pitch_ref_right:
        return 0
    else:
        diff = abs(pitch_ref - pitch_est_new)
        if diff <= 0.6:
            tmp = norm(diff, pitch_ref, pitch_ref_right)
            score = 50 * np.cos(tmp / 2) +50
        else:
            com = lambda x: -198 * x + 198
            score = com(diff)

    return score

def generate_score(pitch_ref, pitch_est):
    pitch_est_new = in_one_octave(pitch_ref, pitch_est)
    score = scoring(pitch_ref, pitch_est_new)
    return score



# x= np.linspace(0,127,1000)
# score = np.zeros(x.shape[0])
# for i in range(x.shape[0]):
#     score[i] = generate_score(40,x[i])
# plt.plot(x, score)
# plt.show()








